<?php 
	$pass=password_hash('amal', PASSWORD_DEFAULT);
	/*Algorithme de hachage ireversible*/
	echo $pass;
?>